#include<stdio.h>
int reverse(int n);
int main(void){
    
}